package com.shanli.weixin.bean;

/**
 * 语言类型
 * 
 * @author alex
 *
 */
public enum LangEnum {
	zh_CN, zh_TW, en
}
